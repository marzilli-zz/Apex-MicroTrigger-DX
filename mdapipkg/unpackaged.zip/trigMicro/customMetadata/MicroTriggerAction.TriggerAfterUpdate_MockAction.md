<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>TriggerAfterUpdate_MockAction</label>
    <protected>false</protected>
    <values>
        <field>Active__c</field>
        <value xsi:type="xsd:boolean">true</value>
    </values>
    <values>
        <field>ApexClass__c</field>
        <value xsi:type="xsd:string">TriggerAfterUpdateTest.MockAction</value>
    </values>
    <values>
        <field>Description__c</field>
        <value xsi:type="xsd:string">Mock Trigger for Trigger After Update Test Class</value>
    </values>
    <values>
        <field>MicroTrigger__c</field>
        <value xsi:type="xsd:string">TriggerAfterUpdateTestMicroTrigger</value>
    </values>
    <values>
        <field>OrderOfExecution__c</field>
        <value xsi:type="xsd:double">1.0</value>
    </values>
</CustomMetadata>
